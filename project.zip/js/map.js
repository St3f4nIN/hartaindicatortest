// Function to join GeoJSON features with the table data based on a common attribute/key
function joinData(geojsonFeatures, tableData, geojsonKey, tableKey) {
    return geojsonFeatures.map(feature => {
        const joinValue = feature.properties[geojsonKey];
        const tableRow = tableData.find(row => row[tableKey] === joinValue);
        return { ...feature, properties: { ...feature.properties, ...tableRow } };
    });
}

// Function to zoom to the full extent of the data on the map
function zoomToFullData(map, data) {
    // Get the bounds of the GeoJSON data on the map
    var bounds = L.geoJSON(data[0]).getBounds();
    bounds.extend(L.geoJSON(data[1]).getBounds()); // Extend bounds with the second layer

    // Fit the map to the bounds
    map.fitBounds(bounds);
}

function getChoroplethStyle(feature, layerType) {
    let intervals, colors;
	//console.log('Functie getChoroplethStyle pentru stratul: ', layerType);
    
    if (layerType === 'layer1') {
        intervals = [0, 250000, 400000, 600000];
    } else if (layerType === 'layer2') {
        intervals = [0, 10000, 50000, 200000];
    }

    colors = ['green', 'yellow', 'orange', 'red'];

    const value = feature.properties.pop_tot; // Adjust the property name as needed
    let fillColor = colors[colors.length - 1]; // Default color for values above the last interval
	
	//console.log('Intervalele sunt: ', intervals);
    for (let i = intervals.length - 1; i >= 0; i--) {
        if (value >= intervals[i]) {
            fillColor = colors[i];
            break;
        }
    }

    return {
        fillColor: fillColor,
        weight: 1,
        opacity: 1,
        color: 'white',
        fillOpacity: 0.7
    };
}

let selectedLayer = null;

function setupMap(map, osm, data) {
    var geojsonLayer1 = L.geoJSON(data[0], {
        onEachFeature: function (feature, layer) {
            // Add popups for each feature
            var popupContent = '<b>Județ: </b>' + feature.properties.name;

            // Access the additional properties from the joined CSV
            if (feature.properties.pop_tot) {
                popupContent += '<br><b>Populatie total: </b>' + feature.properties.pop_tot;
            }

            // Access the additional properties from the joined CSV
            if (feature.properties['0 - 4']) {
                popupContent += '<br><b>Populatie 0 - 4: </b>' + feature.properties['0 - 4'];
            }

            layer.bindPopup(popupContent);
			
			// Add tooltips to the map
            if (feature.properties.nume) {
                layer.bindTooltip(feature.properties.nume, {
                    permanent: true, // Make the tooltip hide on mouseout
                    direction: 'center', // Center the tooltip on the mouse pointer
                    className: 'feature-tooltip', // Custom CSS class for styling the tooltip
                    offset: [0, 0] // Set the tooltip offset to center on the mouse pointer
                });
            }
			layer.on('add', function () {
            selectedLayer = layer;
			});
        },
        style: function (feature) {
			return getChoroplethStyle(feature, 'layer1');
		}
    });


    var geojsonLayer2 = L.geoJSON(data[1], {
        onEachFeature: function (feature, layer) {
            // Add popups for each feature
            var popupContent = '<b>Date statistice</b>' +
                '<br><b>Județ: </b>' + feature.properties.county +
                '<br><b>Siruta: </b>' + feature.properties.natcode +
                '<br><b>UAT: </b>' + feature.properties.name;

            // Access the additional properties from the joined CSV
            if (feature.properties.pop_tot) {
                popupContent += '<br><b>Populatie total: </b>' + feature.properties.pop_tot;
            }

            layer.bindPopup(popupContent);
        },
        style: function (feature) {
			return getChoroplethStyle(feature, 'layer2');
		}
    });

    // Load and parse judete_pop.csv and uat_pop.csv
    var judetePopUrl = 'http://localhost:8000/date/judete_pop.csv';
    var uatPopUrl = 'http://localhost:8000/date/uat_pop.csv';
    
	Promise.all([fetch(judetePopUrl), fetch(uatPopUrl)])
        .then(responses => Promise.all(responses.map(response => response.text())))
        .then(csvData => {
            // Convert CSV data to JSON using PapaParse
            var judetePopData = Papa.parse(csvData[0], { header: true, skipEmptyLines: true }).data;
            var uatPopData = Papa.parse(csvData[1], { header: true, skipEmptyLines: true }).data;

            // Join GeoJSON features with the table data for both layers
            const joinedGeojsonLayer1 = joinData(data[0].features, judetePopData, 'natCode', 'natCode');
            const joinedGeojsonLayer2 = joinData(data[1].features, uatPopData, 'natcode', 'natcode');

            // Update the data in the layers with the joined data
            geojsonLayer1.clearLayers();
            geojsonLayer1.addData(joinedGeojsonLayer1);

            geojsonLayer2.clearLayers();
            geojsonLayer2.addData(joinedGeojsonLayer2);

            // Add both layers to the map and control
            var Basemaps = {
                "OSM": osm
            };

            var Overlays = {
                "Judete Layer": geojsonLayer1,
                "UAT Layer": geojsonLayer2
            };

            geojsonLayer1.options.maxZoom = 10;
            geojsonLayer2.options.minZoom = 10;

            // Add the layers to the map initially
            geojsonLayer1.addTo(map);

            var overlayControl = L.control.layers(Basemaps, Overlays).addTo(map);
			
			// Define intervals and colors for both layers
			var layer1Intervals = [0, 250000, 400000, 600000];
			var layer2Intervals = [0, 10000, 50000, 200000];
			var colors = ['green', 'yellow', 'orange', 'red'];

			// Function to create a legend for a specific layer
			function createLegend(intervals) {
				var legend = L.control({ position: 'bottomright' });
				
				legend.onAdd = function (map) {
					var div = L.DomUtil.create('div', 'info legend');
					
					// Loop through the intervals to generate a label with a colored square for each interval
					for (var i = 0; i < intervals.length; i++) {
						div.innerHTML +=
							'<i style="background:' + colors[i] + '"></i> ' +
							intervals[i] + (intervals[i + 1] ? '&ndash;' + intervals[i + 1] + '<br>' : '+');
					}
					
					return div;
				};
				
				return legend;
			}

			// Create legends for both layers
			var legendLayer1 = createLegend(layer1Intervals);
			var legendLayer2 = createLegend(layer2Intervals);

			// Add initial legend to the map (for geojsonLayer1 by default)
			legendLayer1.addTo(map);

			// Function to update the legend based on the visible layer
			function updateLegend(layerType) {
				if (layerType === 'layer1') {
					legendLayer1.addTo(map);
					map.removeControl(legendLayer2);
				} else if (layerType === 'layer2') {
					legendLayer2.addTo(map);
					map.removeControl(legendLayer1);
				}
			}

			// Hide/show the UAT Layer based on the zoom level
			map.on('zoomend', function () {
				if (map.getZoom() >= 10) {
					if (map.hasLayer(geojsonLayer1)) {
						map.removeLayer(geojsonLayer1);
						updateLegend('layer2');
					}
				} else {
					if (!map.hasLayer(geojsonLayer1)) {
						map.addLayer(geojsonLayer1);
						updateLegend('layer1');
					}
				}
			});

			map.on('zoomend', function () {
				if (map.getZoom() < 10) {
					if (map.hasLayer(geojsonLayer2)) {
						map.removeLayer(geojsonLayer2);
						updateLegend('layer1');
					}
				} else {
					if (!map.hasLayer(geojsonLayer2)) {
						map.addLayer(geojsonLayer2);
						updateLegend('layer2');
					}
				}
			});
			
            // Add event listener for the button click
            document.getElementById('zoomToFullData').addEventListener('click', function () {
                zoomToFullData(map, data);
            });
			
			zoomToFullData(map, data);
			
			// Create a search control for geojsonLayer2
			var searchControl = L.control({
				position: 'topright'
			});
			
			
			function updateSearchOptions(selectedCounty) {
				//console.log('Functie update Selected county:', selectedCounty);
				var nameOptions = [];
				//console.log('Functie update nameOption gol:', nameOptions);
				
				if (!selectedCounty || selectedCounty === '') {
					joinedGeojsonLayer2.forEach(function (feature) {
						nameOptions.push(feature.properties.name);
					});
				} else {
					joinedGeojsonLayer2.forEach(function (feature) {
						if (feature.properties.county === selectedCounty) {
							nameOptions.push(feature.properties.name);
						}
					});
				}
				
				//console.log('Functie update nameoption populat:', nameOptions);

				var nameSelect = document.getElementById('search-name');
				//var nameSelect = container.querySelector('#search-name');
				//console.log('Functie update nameselect:', nameSelect);
				nameSelect.innerHTML = ''; // Clear previous options
				
				// Populate the 'search-name' select element with the options
				nameOptions.forEach(function (name) {
					var option = document.createElement('option');
					//console.log('Functie in update name:', option);
					//console.log('Functie in update option:', name);
					option.value = name;
					option.textContent = name;
					nameSelect.appendChild(option);
				});
				//console.log('Functie update nameoption dupa:', nameOptions);
			}
			
			var countyOptions;
			// Declare the container variable 
			var container;
			
			searchControl.onAdd = function (map) {
				container = L.DomUtil.create('div', 'search-container');
				
				
				//console.log('Before population of search-county:');
				//selectedCounty = document.getElementById('search-county'); 
				//console.log('s-a selectat un county:', selectedCounty);

				// Populate the county options
				countyOptions = Array.from(new Set(joinedGeojsonLayer2.map(function (feature) {
					return feature.properties.county; 
				})));
				
				// Sort the countyOptions alphabetically
				countyOptions.sort();

				var countyOptionsHTML = countyOptions
					.map(county => `<option value="${county}">${county}</option>`)
					.join('');
				//console.log('After population of search-county2:', countyOptions);
				
				container.innerHTML = `
					<select id="search-county">
						<option value="">Select County</option>
						${countyOptionsHTML}
					</select>
					<select id="search-name">
						<option value="">Select Name</option>
					</select>
					<button id="search-btn">Search</button>
				`;
				
				// Call the updateSearchOptions function to populate the name options
				updateSearchOptions();

				//var nameSelect = document.getElementById('search-name'); // Get the 'search-name' 	dropdown
				var nameSelect = container.querySelector('#search-name');
				
				//console.log('s-a selectat un nume:', nameSelect);
				
				nameSelect.addEventListener('change', function (event) {
					var selectedName = event.target.value;
					//console.log('Dupa ce s-a selectat un nume:', selectedName);
					// Perform any additional action you want when the name is selected (if needed)
				});
			    
				
				//var searchButton = document.getElementById('search-btn');
				var searchButton = container.querySelector('#search-btn');
				searchButton.addEventListener('click', function () {
					var selectedCounty = container.querySelector('#search-county').value;
					var selectedName = container.querySelector('#search-name').value;

					if (selectedCounty && selectedName) {
						var selectedFeature = joinedGeojsonLayer2.find(function (feature) {
							return feature.properties.county === selectedCounty && feature.properties.name === selectedName;
						});

						if (selectedFeature) {
							var bounds = L.geoJSON(selectedFeature).getBounds();
							map.fitBounds(bounds);

							// Remove the style from previously selected layer (if any)
							if (selectedLayer) {
								selectedLayer.setStyle({ weight: 1, color: 'white' });
							}

							selectedLayer = geojsonLayer2.getLayers().find(layer => {
								return layer.feature.properties.county === selectedCounty && layer.feature.properties.name === selectedName;
							});

							if (selectedLayer) {
								// Highlight the selected layer
								selectedLayer.setStyle({ weight: 5, color: 'red' });
								
								// Bring the selected layer to the front
								selectedLayer.bringToFront();

								// Update the label to show the selected name
								updateSelectedLabel(selectedName);
							}
						}
					}
				});
				
			//var selectCounty = document.getElementById('search-county');
			var selectCounty = container.querySelector('#search-county');
			//console.log('selectCounty dupa document:', selectCounty);

			selectCounty.addEventListener('change', function (event) {
				var selectedCounty = event.target.value;
				//console.log('County select element:', selectedCounty);
				updateSearchOptions(selectedCounty);
			});
			//console.log('Event listener attached!');

				return container;
			};



			searchControl.addTo(map);
			
			// Add buttons to the layer control
			overlayControl._container.innerHTML += `<div><button id="open-table-layer1">Open Table Layer 1</button></div>`;
			overlayControl._container.innerHTML += `<div><button id="open-table-layer2">Open Table Layer 2</button></div>`;
			
			// Add event listeners to the buttons


			
			document.getElementById('open-table-layer2').addEventListener('click', function () {
				console.log('s-a apasat butonul tb 2');
				const tableContainerLayer2 = document.getElementById('table-container-layer2');

				// Toggle the display of the table container
				if (tableContainerLayer2.style.display === 'block') {
					tableContainerLayer2.style.display = 'none';
				} else {
					// Show the table for Layer 2 and hide the table for Layer 1
					tableContainerLayer2.style.display = 'block';

					// Populate the county filter dropdown
					populateCountyFilterDropdown();

					// Get the first county alphabetically
					const firstCounty = countyOptions[0];
					console.log('first county  este: ',firstCounty)

					// Call the updateTableContentForLayer2 function with the first county
					updateTableContentForLayer2(firstCounty);
				}
			});
			
			document.getElementById('open-table-layer1').addEventListener('click', function () {
				console.log('S-a apasat but tbl1');
				const tableContainerLayer1 = document.getElementById('table-container-layer1');
				const tableContentLayer1 = generateTableContentForLayer1(geojsonLayer1.getLayers());
				
				if (tableContainerLayer1.style.display === 'block') {
					tableContainerLayer1.style.display = 'none';
				} else {
					tableContainerLayer1.style.display = 'block';
					tableContainerLayer1.innerHTML = tableContentLayer1;
				}
			});
		

			// Function to generate table content for Layer 1
			function generateTableContentForLayer1(layers) {
				let tableHTML = '<h3>Layer 1 Data</h3><table><tr><th>Name</th><th>Population</th></tr>';

				layers.forEach(layer => {
				  const name = layer.feature.properties.name;
				  const population = layer.feature.properties.pop_tot;

				  tableHTML += `<tr data-name="${name}"><td>${name}</td><td>${population}</td></tr>`;
				});

				tableHTML += '</table>';
				return tableHTML;
			}
			
			
			// Function to generate table content for Layer 2
			function generateTableContentForLayer2(layers, selectedCounty) {
				console.log('generateTableContentForLayer2(layers, selectedCounty) is being called. variables: ',layers,' AND ',selectedCounty);
				let tableHTML = '<h3>Layer 2 Data</h3><table><tr><th>Name</th><th>Population</th></tr>';

				layers.forEach(layer => {
					const name = layer.feature.properties.name;
					const population = layer.feature.properties.pop_tot;
					const county = layer.feature.properties.county;

					if (!selectedCounty || selectedCounty === county) {
						tableHTML += `<tr data-name="${name}"><td>${name}</td><td>${population}</td></tr>`;
					}
				});

				tableHTML += '</table>';
				return tableHTML;
			}

			function populateCountyFilterDropdown() {
				const countyFilterDropdown = document.getElementById('county-filter');
				if (countyFilterDropdown) {
					// Clear previous options
					countyFilterDropdown.innerHTML = '<option value="">Judete</option>';

					// Populate the dropdown with county options
					countyOptions.forEach(county => {
						const option = document.createElement('option');
						option.value = county;
						option.textContent = county;
						countyFilterDropdown.appendChild(option);
					});

					// Add event listener to update the table when county selection changes
					countyFilterDropdown.addEventListener('change', function () {
						const selectedCounty = countyFilterDropdown.value;
						updateTableContentForLayer2(selectedCounty);
					});
				}
			}
			
			function updateTableContentForLayer2(selectedCounty) {
				console.log('updateTableContentForLayer2(selectedCounty) is being called. Variable: ', selectedCounty);
				const tableContainer = document.getElementById('table-container-layer2');
				const layers = geojsonLayer2.getLayers();

				let tableHTML = '<h3>Layer 2 Data</h3><table><tr><th>Name</th><th>Population</th></tr>';

				layers.forEach(layer => {
					const name = layer.feature.properties.name;
					const population = layer.feature.properties.pop_tot;
					const county = layer.feature.properties.county;

					// Filter rows based on selected county
					if (!selectedCounty || selectedCounty === county) {
						tableHTML += `<tr data-name="${name}"><td>${name}</td><td>${population}</td></tr>`;
					}
					console.log('Var intrare functie:  ', selectedCounty);
					console.log('Valoare coloana selectie ', county);
				});

				tableHTML += '</table>';
				tableContainer.innerHTML = tableHTML;

				// Regenerate the "county-filter" dropdown
				const countyFilterDropdown = document.getElementById('county-filter');
				countyFilterDropdown.innerHTML = '<option value="">Judete</option>';
				countyOptions.forEach(county => {
					const option = document.createElement('option');
					option.value = county;
					option.textContent = county;
					countyFilterDropdown.appendChild(option);
				});
				
				// Add event listener to update the table when county selection changes
				countyFilterDropdown.addEventListener('change', function () {
					const selectedCounty = countyFilterDropdown.value;
					updateTableContentForLayer2(selectedCounty);
				});
			}

			
			
			
			// Function to highlight a selected polygon and zoom to its extent (with minimum zoom level)
			function highlightPolygon(layer, name) {
				console.log('highlightPolygon(layer, name) is being called.');
				if (selectedLayer) {
					selectedLayer.setStyle({weight: 1, color: 'white' });
				}
				selectedLayer = layer.getLayers().find(layer => {
					return layer.feature.properties.name === name;
				});

				if (selectedLayer) {
					// Highlight the selected layer
					selectedLayer.setStyle({weight: 5, color: 'blue' });

					// Bring the selected layer to the front
					selectedLayer.bringToFront();

					// Get the bounds of the selected polygon
					const bounds = selectedLayer.getBounds();

					// Calculate the best zoom level that fits the polygon within the map's viewport
					const bestZoom = map.getBoundsZoom(bounds);

					// Set the new zoom level and center the map on the polygon based on the selected layer
					if (layer === geojsonLayer1) {
						// Adjust the zoom level if needed for layer 1
						const finalZoom = 9;
						map.setView(bounds.getCenter(), finalZoom);
					} else if (layer === geojsonLayer2) {
						// Adjust the zoom level if needed for layer 2
						const finalZoom = bestZoom - 1; 
						map.setView(bounds.getCenter(), finalZoom);
					}

					// Show the label with appropriate information using requestAnimationFrame
					requestAnimationFrame(() => {
						updateSelectedLabel(name, true, selectedLayer.feature.properties);
					});
				} else {
					// Hide the label
					updateSelectedLabel('', false);
				}
			}




			
			// Add event listeners to the table rows for layer 1
			document.getElementById('table-container-layer1').addEventListener('click', function (event) {
				const selectedName = event.target.parentElement.getAttribute('data-name');
				if (selectedName) {
					highlightPolygon(geojsonLayer1, selectedName);
				}
			});

			// Add event listeners to the table rows for layer 2
			document.getElementById('table-container-layer2').addEventListener('click', function (event) {
				const selectedName = event.target.parentElement.getAttribute('data-name');
				if (selectedName) {
					highlightPolygon(geojsonLayer2, selectedName);
				}
			});
			

			
			
			// Function to update the label with the selected name
			function updateSelectedLabel(name, isVisible, properties) {
				console.log('updateSelectedLabel(name) is being called.');
				var label = document.getElementById('selected-name-label');
				if (label) {
					let labelText = `Name: ${name}<br>`;
					
					if (properties.pop_tot !== undefined) {
						labelText += `Population Total: ${properties.pop_tot}<br>`;
					}
					
					if (properties['0 - 4'] !== undefined) {
						labelText += `Age Range (0 - 4): ${properties['0 - 4']}<br>`;
					}
					
					label.innerHTML = labelText.trim();
					label.style.visibility = isVisible ? 'visible' : 'hidden';
					console.log('Vizibil? ', label.style.visibility);
				}
			}


		});
}
